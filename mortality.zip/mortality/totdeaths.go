package main

import (
    "fmt"
	"strconv"
    "strings"
    "github.com/ctessum/geom/index/rtree"
	"github.com/ctessum/geom"
	"github.com/ctessum/geom/encoding/shp"
    "math"
//	"github.com/fhs/go-netcdf/netcdf"
//	"github.com/spatialmodel/inmap"
)

const (
    hammer      = "./inputs/totalpm.shp"
    pol         = "TotalPM25"
    resultFile  = "../avg.shp"
//    resultFile  = "/Users/sumilthakrar/UMN/Projects/HealthAQ/DanTong2021/Dantong2021-Dantong2021-Globalpower_in_scenarios-588983d/To_run/results/dantong.shp"
    popFile     = "./inputs/pop.shp"
    demog       = "./inputs/age25.shp"
    countryShp  = "./inputs/global-popfracs.shp"
    acmort      = "./inputs/allcause.shp"
    ijhat       = "./inputs/ijHat-all_25-regridded.shp"
)

func main(){
    fmt.Println("starting")
    fmt.Println("reading total PM2.5")
    inmapCells, totpm           := getTots(hammer, "TotalPM25")
    fmt.Println("reading results")
	var RRs, deaths []float64
    oldCells, resultpma         := getShpData(resultFile, "TotalPM25")
    fmt.Println("regridding results")
    resultpm, err               := regrid(oldCells, inmapCells, resultpma)
    check(err)
    fmt.Println("reading population")
    _, population              := getShpData(popFile, "TotalPop")
//    _, populationa              := getShpData(resultFile, "TotalPop")
//    population, err             := regridSum(oldCells, inmapCells, populationa)
//    check(err)
    _, countryRegrid            := getTots(demog, "RRs")
    _, allcausemort             := getTots(acmort, "RRs")
    _, ijhat                    := getTots(ijhat, "RRs")

    fmt.Println("getting total deaths")
    var maxConc []float64
    for t := range totpm {
        var concs float64
        concs = math.Max(resultpm[t],totpm[t])
        maxConc = append(maxConc, concs)
        concs = totpm[t]
        RRs = append(RRs, GEMM(concs, 0.1430,1.6,15.5,36.8))
        dd := (GEMM(concs, 0.1430, 1.6, 15.5, 36.8) - 1) * (population[t] / ijhat[t]) * countryRegrid[t] * allcausemort[t] / 100000
        deaths = append(deaths, dd)
    }

// Save that out, as the deaths attributable to the InMAP results.
//    fmt.Println("writing total deaths to file")
    writeTotDeaths(inmapCells, deaths, "deaths-dt.shp")

// You will want to regrid-sum attrib back to the country shapefile to
// get results by country.
//    countryShapes, countryName  := getShpData(countryShp, "OBJECTID")
//    rattrib, err                := regridSum(inmapCells, countryShapes, attrib)
//    check(err)
//    writeOutCountries(countryShapes, rattrib, "country-deaths-so2-ex.shp", countryName)

}


// Regrid just the '25+' parameters to the InMAP grid (for total deaths)
// (The disease- and age-specific deaths (and pollutant specific deaths) can come later. Just get it all working for now).

// Regrid-sum the population to the State file (ASEAN data)









//const (
//    θ       =   0.1430
//    α       =   1.6
//    μ       =   15.5
//    v       =   36.8
//)

func GEMM(z, θ, α, μ, v float64) (float64) {
    z       =       math.Max(z-2.4,0)
    denom   :=      1.0 + math.Exp(-(z-μ)/v)
    numer   :=      θ * math.Log((z/α)+1)
    return math.Exp(numer/denom)
}

//func readGBD() ([]float64) {

//}

//func assignToStates(df ???, stateVals []string, mapping ???) (gbdVals []string) {
//}

func writeShpData(cells []geom.Polygonal, native, regridded []float64) {
	type shpOut struct {
		geom.Polygon
		Native, Regridded, Diff float64
	}

	e, err := shp.NewEncoder("regridded-states-to-InMAP-Cells.shp", shpOut{})
	check(err)
	for i, c := range cells {
		check(e.Encode(shpOut{
			Polygon:   c.Polygons()[0], // Need to change if ever using a multipolygon here.
			Native:    native[i],
			Regridded: regridded[i],
			Diff:      regridded[i] - native[i],
		}))
	}
	e.Close()
}

func writeTotDeaths(cells []geom.Polygonal, native []float64, filename string) {
	type shpOut struct {
		geom.Polygon
		RRs float64
	}

	e, err := shp.NewEncoder(filename, shpOut{})
	check(err)
	for i, c := range cells {
		check(e.Encode(shpOut{
			Polygon:   c.Polygons()[0], // Need to change if ever using a multipolygon here.
			RRs:    native[i],
		}))
	}
	e.Close()
}

func writeOutCountries(cells []geom.Polygonal, native []float64, filename string, countryName []float64) {
	type shpOut struct {
		geom.Polygon
		deaths float64
        country float64
	}

	e, err := shp.NewEncoder(filename, shpOut{})
	check(err)
	for i, c := range cells {
		check(e.Encode(shpOut{
			Polygon:   c.Polygons()[0], // Need to change if ever using a multipolygon here.
			deaths:    native[i],
            country:   countryName[i],
		}))
	}
	e.Close()
}


// Handle errors
func check(err error) {
	if err != nil {
		panic(err)
	}
}

// Getting the state data (strings).
func getStateData(shpFile, pol string) ([]geom.Polygonal, []string) {
	s, err := shp.NewDecoder(shpFile)
	check(err)

	var data []string
	var cells []geom.Polygonal
	for {
		g, fields, more := s.DecodeRowFields(pol)
		if !more {
			break
		}
		v := fields[pol]
		cells = append(cells, g.(geom.Polygonal))
		data = append(data, v)

	}
	s.Close()
	check(s.Error())
	return cells, data
}

// Read shapefile data
func getTots(shpFile, pol string) ([]geom.Polygonal, []float64) {
	s, err := shp.NewDecoder(shpFile)
	check(err)

	var data []float64
	var cells []geom.Polygonal
	for {
		g, fields, more := s.DecodeRowFields(pol)
		if !more {
			break
		}
        mm := strings.Replace(fields[pol]," ","",-1)
        v, err := strconv.ParseFloat(strings.Replace(mm,"\x00", "", -1),64)
        check(err)
		cells = append(cells, g.(geom.Polygonal))
		data = append(data, v)
	}
	s.Close()
	check(s.Error())
	return cells, data
}

func getShpData(shpFile, pol string) ([]geom.Polygonal, []float64) {
	s, err := shp.NewDecoder(shpFile)
	check(err)

	var data []float64
	var cells []geom.Polygonal
	for {
		g, fields, more := s.DecodeRowFields(pol)
		if !more {
			break
		}
		v, err := strconv.ParseFloat(fields[pol], 64)
		check(err)
		cells = append(cells, g.(geom.Polygonal))
		data = append(data, v)

	}
	s.Close()
	check(s.Error())
	return cells, data
}


// Regrid regrids concentration data from one spatial grid to a
// different one.
func regrid(oldGeom, newGeom []geom.Polygonal, oldData []float64) (newData []float64, err error) {
    type data struct {
        geom.Polygonal
        data float64
    }
    if len(oldGeom) != len(oldData) {
        return nil, fmt.Errorf("oldGeom and oldData have different lengths: %d!=%d", len(oldGeom), len(oldData))
    }
    index := rtree.NewTree(25, 50)
    for i, g := range oldGeom {
        index.Insert(&data{
            Polygonal: g,
            data:      oldData[i],
        })
    }
    newData = make([]float64, len(newGeom))
    for i, g := range newGeom {
        for _, dI := range index.SearchIntersect(g.Bounds()) {
            d := dI.(*data)
            isect := g.Intersection(d.Polygonal)
            if isect == nil {
                continue
            }
            a := isect.Area()
            frac := a / g.Area()
            newData[i] += d.data * frac
        }
    }
    return newData, nil
}

func regridSum(oldGeom, newGeom []geom.Polygonal, oldData []float64) (newData []float64, err error) {
    type data struct {
        geom.Polygonal
        data float64
    }
    if len(oldGeom) != len(oldData) {
        return nil, fmt.Errorf("oldGeom and oldData have different lengths: %d!=%d", len(oldGeom), len(oldData))
    }
    index := rtree.NewTree(25, 50)
    for i, g := range oldGeom {
        index.Insert(&data{
            Polygonal: g,
            data:      oldData[i],
        })
    }
    newData = make([]float64, len(newGeom))
    for i, g := range newGeom {
        for _, dI := range index.SearchIntersect(g.Bounds()) {
            d := dI.(*data)
            isect := g.Intersection(d.Polygonal)
            if isect == nil {
                continue
            }
            a := isect.Area()
            frac := a / d.Polygonal.Area()
            newData[i] += d.data * frac
        }
    }
    return newData, nil
}
